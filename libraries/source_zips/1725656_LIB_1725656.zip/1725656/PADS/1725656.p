*PADS-LIBRARY-PART-TYPES-V9*

1725656 1725656 I CON 9 1 0 0 0
TIMESTAMP 2026.11.03.21.39.01
"Manufacturer_Name" Phoenix Contact
"Manufacturer_Part_Number" 1725656
"Mouser Part Number" 651-1725656
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Phoenix-Contact/1725656?qs=Ul7CXFMnlWWQeccayYbRmw%3D%3D
"Arrow Part Number" 1725656
"Arrow Price/Stock" https://www.arrow.com/en/products/1725656/phoenix-contact.html?utm_currency=USD&region=nac
"Description" MPT 0,5/ 2-2,54 - Printed circuit board terminal, nominal current: 6 A, rated voltage (III/2): 160 V, nominal cross section: 0.5 mm<sup>2</sup>, number of potentials: 2, number of rows: 1, number of positions per row: 2, product range: MPT 0,5, pitch: 2.54 mm, connection method: Screw connection with tension sleeve, screw head form: L Slotted, mounting: Wave soldering, conductor/PCB connection direction: 0 , color: green, Pin layout: Linear pinning, Solder pin [P]: 3.5 mm, number of solder pins per potenti
"Datasheet Link" https://www.phoenixcontact.com/en-us/products/printed-circuit-board-terminal-mpt-05-2-254-1725656?type=pdf
"Geometry.Height" 8.65mm
GATE 1 2 0
1725656
1 0 U 1
2 0 U 2

*END*
*REMARK* SamacSys ECAD Model
246260/2096105/2.50/2/2/Connector
