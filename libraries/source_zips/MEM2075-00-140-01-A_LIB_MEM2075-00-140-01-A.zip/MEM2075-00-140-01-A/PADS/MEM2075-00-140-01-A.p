*PADS-LIBRARY-PART-TYPES-V9*

MEM2075-00-140-01-A MEM20750014001A I CON 9 1 0 0 0
TIMESTAMP 2026.11.03.23.14.23
"Manufacturer_Name" GCT (GLOBAL CONNECTOR TECHNOLOGY)
"Manufacturer_Part_Number" MEM2075-00-140-01-A
"Mouser Part Number" 640-MEM20750014001A
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/GCT/MEM2075-00-140-01-A?qs=KUoIvG%2F9IlZvfWpeERlq3Q%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" GCT (GLOBAL CONNECTOR TECHNOLOGY) - MEM2075-00-140-01-A - MICRO SD CARD CONN, PUSH-PUSH, 9POS, SMT
"Datasheet Link" http://www.farnell.com/cad/2606866.pdf
"Geometry.Height" 1.45mm
GATE 1 13 0
MEM2075-00-140-01-A
1 0 U DAT2
2 0 U CD/DAT3
3 0 U CMD
4 0 U VDD
5 0 U CLK
6 0 U VSS
7 0 U DAT0
8 0 U DAT1
9 0 U CD
10 0 U MP1
11 0 U MP2
12 0 U MP3
13 0 U MP4

*END*
*REMARK* SamacSys ECAD Model
1372791/2096105/2.50/13/4/Connector
