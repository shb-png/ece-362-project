*PADS-LIBRARY-PART-TYPES-V9*

M20-7820546 RHDR5W70P0X254_1X5_1310X250X850P I CON 9 1 0 0 0
TIMESTAMP 2026.11.03.23.03.12
"Manufacturer_Name" Harwin
"Manufacturer_Part_Number" M20-7820546
"Mouser Part Number" 855-M20-7820546
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Harwin/M20-7820546?qs=vF78I%252BjhbY9HKICpLl9EpQ%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" M20: 5 Pos Receptacle SIL Straight 3mm THT Connector 8.5mm high Tin
"Datasheet Link" https://content.harwin.com/m/c2ac50ebb1c800d5/original/DRG-00385-Technical-Drawing-Datasheet-M20-782-pdf.pdf
"Geometry.Height" 8.5mm
GATE 1 5 0
M20-7820546
1 0 U 1
2 0 U 2
3 0 U 3
4 0 U 4
5 0 U 5

*END*
*REMARK* SamacSys ECAD Model
479573/2096105/2.50/5/2/Connector
