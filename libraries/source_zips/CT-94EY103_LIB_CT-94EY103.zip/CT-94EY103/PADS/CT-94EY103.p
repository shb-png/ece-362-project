*PADS-LIBRARY-PART-TYPES-V9*

CT-94EY103 CT94EY103 I SWI 9 1 0 0 0
TIMESTAMP 2026.11.03.21.43.43
"Manufacturer_Name" Nidec Copal
"Manufacturer_Part_Number" CT-94EY103
"Mouser Part Number" 229-CT-94EY103
"Mouser Price/Stock" https://www.mouser.co.uk/ProductDetail/Nidec-Copal/CT-94EY103?qs=XeJtXLiO41TsH3gRd1kurw%3D%3D
"Arrow Part Number" 
"Arrow Price/Stock" 
"Description" Trimmer Resistors - Through Hole 10 KW 9mm sq. multi turn top adjust
"Datasheet Link" https://www.mouser.de/datasheet/2/972/ct-94-1827503.pdf
"Geometry.Height" 9.9mm
GATE 1 3 0
CT-94EY103
1 0 U CCW
2 0 U WIPER
3 0 U CW

*END*
*REMARK* SamacSys ECAD Model
13331689/2096105/2.50/3/4/Switch
